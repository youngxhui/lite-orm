create view tmp_id as
  select `eva`.`uek_privilege_menu`.`id` AS `id`
  from `eva`.`uek_privilege_menu`
  where ((not (`eva`.`uek_privilege_menu`.`parent_id` in (select `eva`.`uek_privilege_menu`.`id`
                                                          from `eva`.`uek_privilege_menu`
                                                          where `eva`.`uek_privilege_menu`.`parent_id` in
                                                                (select `eva`.`uek_privilege_menu`.`id`
                                                                 from `eva`.`uek_privilege_menu`
                                                                 where ((`eva`.`uek_privilege_menu`.`name` in
                                                                         ('系统管理', '人力行政', '教务管理', '就业服务')) and isnull(
                                                                            `eva`.`uek_privilege_menu`.`parent_id`))))))
         and (not (`eva`.`uek_privilege_menu`.`parent_id` in (select `eva`.`uek_privilege_menu`.`id`
                                                              from `eva`.`uek_privilege_menu`
                                                              where ((`eva`.`uek_privilege_menu`.`name` in
                                                                      ('系统管理', '人力行政', '教务管理', '就业服务')) and isnull(
                                                                         `eva`.`uek_privilege_menu`.`parent_id`))))));

